
    printf("%d %s", n, str);